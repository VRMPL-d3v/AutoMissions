AUTO MISSIONS - LICENÇA PROPRIETÁRIA (PORTUGAL)

Copyright (c) 2025 VRMPL_d3v. Todos os direitos reservados.
Website: https://vrmpld3v.netlify.app/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION (PT-PT)

1. PARTES
   "Licenciante" refere-se a VRMPL_d3v, titular de todos os direitos de propriedade intelectual relativos ao software denominado "Auto Missions".
   "Licenciado" refere-se a qualquer pessoa ou entidade que receba ou obtiver acesso ao Software.

2. DEFINIÇÕES
   "Software" significa a aplicação Auto Missions e todos os seus componentes, incluindo, sem limitação:
   código-fonte, código-objeto, scripts, bibliotecas, executáveis, recursos, documentação, atualizações e patches.

3. CONCESSÃO DE LICENÇA (LIMITADA)
   O Licenciante concede ao Licenciado uma licença limitada, não-exclusiva, intransmissível e revogável para UTILIZAR o Software apenas para fins pessoais e internos, e apenas na forma expressamente permitida por este contrato.
   Nenhum direito é concedido para sublicenciar, redistribuir, modificar ou explorar comercialmente o Software sem autorização escrita prévia do Licenciante.

4. AÇÕES PROIBIDAS
   Sem autorização prévia e por escrito do Licenciante, o Licenciado NÃO PODE:
   a) Modificar, adaptar, traduzir ou criar obras derivadas do Software;
   b) Descompilar, fazer engenharia inversa, desmontar ou tentar derivar o código-fonte do Software;
   c) Distribuir, vender, sublicenciar, alugar, ceder, publicar ou de outra forma transferir o Software ou quaisquer obras derivadas;
   d) Remover, alterar ou ocultar avisos de copyright, marcas ou outros avisos proprietários contidos no Software;
   e) Contornar, desativar ou adulterar quaisquer mecanismos de segurança, verificação de integridade, licenciamento ou proteção incluídos no Software.

5. VERIFICAÇÃO DE INTEGRIDADE
   O Software pode incluir mecanismos de verificação de integridade (por exemplo, verificação de hash). Qualquer tentativa de modificar ou adulterar essas verificações, ou de distribuir ficheiros modificados de forma a contornar essas verificações, constitui violação material desta Licença.

6. RESCISÃO
   O Licenciante pode rescindir imediatamente esta Licença caso o Licenciado viole qualquer termo aqui dispuesto. Após rescisão, o Licenciado deve cessar todo o uso do Software e destruir todas as cópias em sua posse.

7. ISENÇÃO DE GARANTIAS
   O Software é fornecido "NO ESTADO EM QUE SE ENCONTRA" ("AS IS"), sem garantias de qualquer tipo, expressas ou implícitas, incluindo, sem limitação, garantias de comercialização, adequação a um fim específico ou não infração.

8. LIMITAÇÃO DE RESPONSABILIDADE
   EM NENHUMA HIPÓTESE O LICENCIANTE SERÁ RESPONSÁVEL POR QUAISQUER DANOS INDIRETOS, INCIDENTAIS, ESPECIAIS OU CONSEQUENCIAIS DECORRENTES DO USO OU INCAPACIDADE DE USAR O SOFTWARE, MESMO QUE AVISADO DA POSSIBILIDADE DESSES DANOS.

9. LEI APLICÁVEL E JURISDIÇÃO
   Esta Licença será regida e interpretada de acordo com a legislação de Portugal. Quaisquer litígios emergentes desta Licença serão submetidos aos tribunais competentes de Portugal.

10. CONTACTO
   Para pedidos de licença, permissões ou outras questões, contacta:
   VRMPL_d3v
   Discord: 
   Website: https://vrmpld3v.netlify.app/

